﻿namespace Assn1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.eTypeLbl = new System.Windows.Forms.Label();
            this.fbstatusRadButton = new System.Windows.Forms.RadioButton();
            this.tweetRadButton = new System.Windows.Forms.RadioButton();
            this.vidRadButton = new System.Windows.Forms.RadioButton();
            this.photoRadButton = new System.Windows.Forms.RadioButton();
            this.trackRadButton = new System.Windows.Forms.RadioButton();
            this.tracklogPanel = new System.Windows.Forms.Panel();
            this.longTxtBox = new System.Windows.Forms.TextBox();
            this.LatTxtBox = new System.Windows.Forms.TextBox();
            this.fileTxtBox = new System.Windows.Forms.TextBox();
            this.longtrackLbl = new System.Windows.Forms.Label();
            this.lattrackLbl = new System.Windows.Forms.Label();
            this.fileTrackLbl = new System.Windows.Forms.Label();
            this.vidPanel = new System.Windows.Forms.Panel();
            this.vidFileTextBox = new System.Windows.Forms.TextBox();
            this.filepathVideoLbl = new System.Windows.Forms.Label();
            this.TwitterPanel = new System.Windows.Forms.Panel();
            this.dateTimeTwitter = new System.Windows.Forms.DateTimePicker();
            this.tweetdateLbl = new System.Windows.Forms.Label();
            this.tweetTxtBox = new System.Windows.Forms.TextBox();
            this.tweetLbl = new System.Windows.Forms.Label();
            this.photoPanel = new System.Windows.Forms.Panel();
            this.filePhotoTxtBox = new System.Windows.Forms.TextBox();
            this.filephotoLbl = new System.Windows.Forms.Label();
            this.fbPanel = new System.Windows.Forms.Panel();
            this.dateTimeFacebook = new System.Windows.Forms.DateTimePicker();
            this.fbdateLbl = new System.Windows.Forms.Label();
            this.fbstatusTxtBox = new System.Windows.Forms.TextBox();
            this.fbstatLbl = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.tracklogPanel.SuspendLayout();
            this.vidPanel.SuspendLayout();
            this.TwitterPanel.SuspendLayout();
            this.photoPanel.SuspendLayout();
            this.fbPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // eTypeLbl
            // 
            this.eTypeLbl.AutoSize = true;
            this.eTypeLbl.Location = new System.Drawing.Point(44, 26);
            this.eTypeLbl.Name = "eTypeLbl";
            this.eTypeLbl.Size = new System.Drawing.Size(77, 15);
            this.eTypeLbl.TabIndex = 0;
            this.eTypeLbl.Text = "Type of Event";
            // 
            // fbstatusRadButton
            // 
            this.fbstatusRadButton.AutoSize = true;
            this.fbstatusRadButton.Location = new System.Drawing.Point(44, 69);
            this.fbstatusRadButton.Name = "fbstatusRadButton";
            this.fbstatusRadButton.Size = new System.Drawing.Size(111, 19);
            this.fbstatusRadButton.TabIndex = 1;
            this.fbstatusRadButton.TabStop = true;
            this.fbstatusRadButton.Text = "Facebook Status";
            this.fbstatusRadButton.UseVisualStyleBackColor = true;
            this.fbstatusRadButton.CheckedChanged += new System.EventHandler(this.fbstatusRadButton_CheckedChanged);
            // 
            // tweetRadButton
            // 
            this.tweetRadButton.AutoSize = true;
            this.tweetRadButton.Location = new System.Drawing.Point(44, 113);
            this.tweetRadButton.Name = "tweetRadButton";
            this.tweetRadButton.Size = new System.Drawing.Size(55, 19);
            this.tweetRadButton.TabIndex = 1;
            this.tweetRadButton.TabStop = true;
            this.tweetRadButton.Text = "Tweet";
            this.tweetRadButton.UseVisualStyleBackColor = true;
            this.tweetRadButton.CheckedChanged += new System.EventHandler(this.tweetRadButton_CheckedChanged);
            // 
            // vidRadButton
            // 
            this.vidRadButton.AutoSize = true;
            this.vidRadButton.Location = new System.Drawing.Point(44, 160);
            this.vidRadButton.Name = "vidRadButton";
            this.vidRadButton.Size = new System.Drawing.Size(55, 19);
            this.vidRadButton.TabIndex = 1;
            this.vidRadButton.TabStop = true;
            this.vidRadButton.Text = "Video";
            this.vidRadButton.UseVisualStyleBackColor = true;
            this.vidRadButton.CheckedChanged += new System.EventHandler(this.vidRadButton_CheckedChanged);
            // 
            // photoRadButton
            // 
            this.photoRadButton.AutoSize = true;
            this.photoRadButton.Location = new System.Drawing.Point(44, 208);
            this.photoRadButton.Name = "photoRadButton";
            this.photoRadButton.Size = new System.Drawing.Size(57, 19);
            this.photoRadButton.TabIndex = 1;
            this.photoRadButton.TabStop = true;
            this.photoRadButton.Text = "Photo";
            this.photoRadButton.UseVisualStyleBackColor = true;
            this.photoRadButton.CheckedChanged += new System.EventHandler(this.photoRadButton_CheckedChanged);
            // 
            // trackRadButton
            // 
            this.trackRadButton.AutoSize = true;
            this.trackRadButton.Location = new System.Drawing.Point(44, 250);
            this.trackRadButton.Name = "trackRadButton";
            this.trackRadButton.Size = new System.Drawing.Size(72, 19);
            this.trackRadButton.TabIndex = 1;
            this.trackRadButton.TabStop = true;
            this.trackRadButton.Text = "TrackLog";
            this.trackRadButton.UseVisualStyleBackColor = true;
            this.trackRadButton.CheckedChanged += new System.EventHandler(this.trackRadButton_CheckedChanged);
            // 
            // tracklogPanel
            // 
            this.tracklogPanel.Controls.Add(this.longTxtBox);
            this.tracklogPanel.Controls.Add(this.LatTxtBox);
            this.tracklogPanel.Controls.Add(this.fileTxtBox);
            this.tracklogPanel.Controls.Add(this.longtrackLbl);
            this.tracklogPanel.Controls.Add(this.lattrackLbl);
            this.tracklogPanel.Controls.Add(this.fileTrackLbl);
            this.tracklogPanel.Location = new System.Drawing.Point(209, 29);
            this.tracklogPanel.Name = "tracklogPanel";
            this.tracklogPanel.Size = new System.Drawing.Size(232, 248);
            this.tracklogPanel.TabIndex = 2;
            // 
            // longTxtBox
            // 
            this.longTxtBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.longTxtBox.Location = new System.Drawing.Point(103, 108);
            this.longTxtBox.Name = "longTxtBox";
            this.longTxtBox.Size = new System.Drawing.Size(100, 23);
            this.longTxtBox.TabIndex = 1;
            // 
            // LatTxtBox
            // 
            this.LatTxtBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LatTxtBox.Location = new System.Drawing.Point(103, 71);
            this.LatTxtBox.Name = "LatTxtBox";
            this.LatTxtBox.Size = new System.Drawing.Size(100, 23);
            this.LatTxtBox.TabIndex = 1;
            // 
            // fileTxtBox
            // 
            this.fileTxtBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.fileTxtBox.Location = new System.Drawing.Point(103, 39);
            this.fileTxtBox.Name = "fileTxtBox";
            this.fileTxtBox.Size = new System.Drawing.Size(100, 23);
            this.fileTxtBox.TabIndex = 1;
            // 
            // longtrackLbl
            // 
            this.longtrackLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.longtrackLbl.AutoSize = true;
            this.longtrackLbl.Location = new System.Drawing.Point(18, 108);
            this.longtrackLbl.Name = "longtrackLbl";
            this.longtrackLbl.Size = new System.Drawing.Size(64, 15);
            this.longtrackLbl.TabIndex = 0;
            this.longtrackLbl.Text = "Longitude:";
            // 
            // lattrackLbl
            // 
            this.lattrackLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lattrackLbl.AutoSize = true;
            this.lattrackLbl.Location = new System.Drawing.Point(18, 74);
            this.lattrackLbl.Name = "lattrackLbl";
            this.lattrackLbl.Size = new System.Drawing.Size(53, 15);
            this.lattrackLbl.TabIndex = 0;
            this.lattrackLbl.Text = "Latitude:";
            // 
            // fileTrackLbl
            // 
            this.fileTrackLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.fileTrackLbl.AutoSize = true;
            this.fileTrackLbl.Location = new System.Drawing.Point(18, 44);
            this.fileTrackLbl.Name = "fileTrackLbl";
            this.fileTrackLbl.Size = new System.Drawing.Size(55, 15);
            this.fileTrackLbl.TabIndex = 0;
            this.fileTrackLbl.Text = "File Path:";
            // 
            // vidPanel
            // 
            this.vidPanel.Controls.Add(this.vidFileTextBox);
            this.vidPanel.Controls.Add(this.filepathVideoLbl);
            this.vidPanel.Location = new System.Drawing.Point(205, 29);
            this.vidPanel.Name = "vidPanel";
            this.vidPanel.Size = new System.Drawing.Size(232, 247);
            this.vidPanel.TabIndex = 2;
            // 
            // vidFileTextBox
            // 
            this.vidFileTextBox.Location = new System.Drawing.Point(76, 25);
            this.vidFileTextBox.Name = "vidFileTextBox";
            this.vidFileTextBox.Size = new System.Drawing.Size(100, 23);
            this.vidFileTextBox.TabIndex = 1;
            // 
            // filepathVideoLbl
            // 
            this.filepathVideoLbl.AutoSize = true;
            this.filepathVideoLbl.Location = new System.Drawing.Point(13, 28);
            this.filepathVideoLbl.Name = "filepathVideoLbl";
            this.filepathVideoLbl.Size = new System.Drawing.Size(55, 15);
            this.filepathVideoLbl.TabIndex = 0;
            this.filepathVideoLbl.Text = "File Path:";
            // 
            // TwitterPanel
            // 
            this.TwitterPanel.Controls.Add(this.dateTimeTwitter);
            this.TwitterPanel.Controls.Add(this.tweetdateLbl);
            this.TwitterPanel.Controls.Add(this.tweetTxtBox);
            this.TwitterPanel.Controls.Add(this.tweetLbl);
            this.TwitterPanel.Location = new System.Drawing.Point(209, 29);
            this.TwitterPanel.Name = "TwitterPanel";
            this.TwitterPanel.Size = new System.Drawing.Size(237, 247);
            this.TwitterPanel.TabIndex = 2;
            // 
            // dateTimeTwitter
            // 
            this.dateTimeTwitter.Location = new System.Drawing.Point(52, 214);
            this.dateTimeTwitter.Name = "dateTimeTwitter";
            this.dateTimeTwitter.Size = new System.Drawing.Size(163, 23);
            this.dateTimeTwitter.TabIndex = 2;
            // 
            // tweetdateLbl
            // 
            this.tweetdateLbl.AutoSize = true;
            this.tweetdateLbl.Location = new System.Drawing.Point(13, 214);
            this.tweetdateLbl.Name = "tweetdateLbl";
            this.tweetdateLbl.Size = new System.Drawing.Size(34, 15);
            this.tweetdateLbl.TabIndex = 0;
            this.tweetdateLbl.Text = "Date:";
            // 
            // tweetTxtBox
            // 
            this.tweetTxtBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tweetTxtBox.Location = new System.Drawing.Point(23, 43);
            this.tweetTxtBox.Multiline = true;
            this.tweetTxtBox.Name = "tweetTxtBox";
            this.tweetTxtBox.Size = new System.Drawing.Size(200, 134);
            this.tweetTxtBox.TabIndex = 1;
            // 
            // tweetLbl
            // 
            this.tweetLbl.AutoSize = true;
            this.tweetLbl.Location = new System.Drawing.Point(13, 28);
            this.tweetLbl.Name = "tweetLbl";
            this.tweetLbl.Size = new System.Drawing.Size(60, 15);
            this.tweetLbl.TabIndex = 0;
            this.tweetLbl.Text = "Tweet text";
            // 
            // photoPanel
            // 
            this.photoPanel.Controls.Add(this.filePhotoTxtBox);
            this.photoPanel.Controls.Add(this.filephotoLbl);
            this.photoPanel.Location = new System.Drawing.Point(209, 30);
            this.photoPanel.Name = "photoPanel";
            this.photoPanel.Size = new System.Drawing.Size(232, 247);
            this.photoPanel.TabIndex = 2;
            // 
            // filePhotoTxtBox
            // 
            this.filePhotoTxtBox.Location = new System.Drawing.Point(74, 26);
            this.filePhotoTxtBox.Name = "filePhotoTxtBox";
            this.filePhotoTxtBox.Size = new System.Drawing.Size(100, 23);
            this.filePhotoTxtBox.TabIndex = 1;
            // 
            // filephotoLbl
            // 
            this.filephotoLbl.AutoSize = true;
            this.filephotoLbl.Location = new System.Drawing.Point(13, 28);
            this.filephotoLbl.Name = "filephotoLbl";
            this.filephotoLbl.Size = new System.Drawing.Size(55, 15);
            this.filephotoLbl.TabIndex = 0;
            this.filephotoLbl.Text = "File Path:";
            // 
            // fbPanel
            // 
            this.fbPanel.Controls.Add(this.dateTimeFacebook);
            this.fbPanel.Controls.Add(this.fbdateLbl);
            this.fbPanel.Controls.Add(this.fbstatusTxtBox);
            this.fbPanel.Controls.Add(this.fbstatLbl);
            this.fbPanel.Location = new System.Drawing.Point(209, 29);
            this.fbPanel.Name = "fbPanel";
            this.fbPanel.Size = new System.Drawing.Size(232, 247);
            this.fbPanel.TabIndex = 2;
            // 
            // dateTimeFacebook
            // 
            this.dateTimeFacebook.Location = new System.Drawing.Point(52, 214);
            this.dateTimeFacebook.Name = "dateTimeFacebook";
            this.dateTimeFacebook.Size = new System.Drawing.Size(163, 23);
            this.dateTimeFacebook.TabIndex = 2;
            // 
            // fbdateLbl
            // 
            this.fbdateLbl.AutoSize = true;
            this.fbdateLbl.Location = new System.Drawing.Point(13, 214);
            this.fbdateLbl.Name = "fbdateLbl";
            this.fbdateLbl.Size = new System.Drawing.Size(34, 15);
            this.fbdateLbl.TabIndex = 0;
            this.fbdateLbl.Text = "Date:";
            // 
            // fbstatusTxtBox
            // 
            this.fbstatusTxtBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.fbstatusTxtBox.Location = new System.Drawing.Point(18, 43);
            this.fbstatusTxtBox.Multiline = true;
            this.fbstatusTxtBox.Name = "fbstatusTxtBox";
            this.fbstatusTxtBox.Size = new System.Drawing.Size(200, 134);
            this.fbstatusTxtBox.TabIndex = 1;
            // 
            // fbstatLbl
            // 
            this.fbstatLbl.AutoSize = true;
            this.fbstatLbl.Location = new System.Drawing.Point(13, 28);
            this.fbstatLbl.Name = "fbstatLbl";
            this.fbstatLbl.Size = new System.Drawing.Size(39, 15);
            this.fbstatLbl.TabIndex = 0;
            this.fbstatLbl.Text = "Status";
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(209, 289);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(78, 23);
            this.saveButton.TabIndex = 3;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(359, 289);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(78, 23);
            this.cancelButton.TabIndex = 3;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 342);
            this.Controls.Add(this.fbPanel);
            this.Controls.Add(this.photoPanel);
            this.Controls.Add(this.vidPanel);
            this.Controls.Add(this.TwitterPanel);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.tracklogPanel);
            this.Controls.Add(this.trackRadButton);
            this.Controls.Add(this.photoRadButton);
            this.Controls.Add(this.vidRadButton);
            this.Controls.Add(this.tweetRadButton);
            this.Controls.Add(this.fbstatusRadButton);
            this.Controls.Add(this.eTypeLbl);
            this.Name = "Form2";
            this.Text = "Add Event";
            this.tracklogPanel.ResumeLayout(false);
            this.tracklogPanel.PerformLayout();
            this.vidPanel.ResumeLayout(false);
            this.vidPanel.PerformLayout();
            this.TwitterPanel.ResumeLayout(false);
            this.TwitterPanel.PerformLayout();
            this.photoPanel.ResumeLayout(false);
            this.photoPanel.PerformLayout();
            this.fbPanel.ResumeLayout(false);
            this.fbPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label eTypeLbl;
        private System.Windows.Forms.RadioButton fbstatusRadButton;
        private System.Windows.Forms.RadioButton tweetRadButton;
        private System.Windows.Forms.RadioButton vidRadButton;
        private System.Windows.Forms.RadioButton photoRadButton;
        private System.Windows.Forms.RadioButton trackRadButton;
        private System.Windows.Forms.Panel tracklogPanel;
        private System.Windows.Forms.Label longtrackLbl;
        private System.Windows.Forms.Label lattrackLbl;
        private System.Windows.Forms.Label fileTrackLbl;
        private System.Windows.Forms.TextBox longTxtBox;
        private System.Windows.Forms.TextBox LatTxtBox;
        private System.Windows.Forms.TextBox fileTxtBox;
        private System.Windows.Forms.Panel vidPanel;
        private System.Windows.Forms.TextBox vidFileTextBox;
        private System.Windows.Forms.Label filepathVideoLbl;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Panel photoPanel;
        private System.Windows.Forms.Panel TwitterPanel;
        private System.Windows.Forms.TextBox tweetTxtBox;
        private System.Windows.Forms.Label tweetLbl;
        private System.Windows.Forms.TextBox filePhotoTxtBox;
        private System.Windows.Forms.Label filephotoLbl;
        private System.Windows.Forms.DateTimePicker dateTimeTwitter;
        private System.Windows.Forms.Label tweetdateLbl;
        private System.Windows.Forms.Panel fbPanel;
        private System.Windows.Forms.DateTimePicker dateTimeFacebook;
        private System.Windows.Forms.Label fbdateLbl;
        private System.Windows.Forms.TextBox fbstatusTxtBox;
        private System.Windows.Forms.Label fbstatLbl;
        private System.Windows.Forms.Panel P;
    }
}