﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assn1
{
    /// <summary>
    /// Values for each event
    /// </summary>
    class Tweet
    {
         private String eventID;
         private String text;
         private double lat;
         private double longt;
         private String dateTimeStamp;

         public Tweet(String eventID, String text, double lat, double longt, String dateTimeStamp)
            {
                 this.eventID = eventID;
                 this.text = text;
                 this.lat = lat;
                 this.longt = longt;
                 this.dateTimeStamp = dateTimeStamp;
            }

         public String EventID
            {
                get { return eventID; }
                set { eventID = value; }
            }

         public String Text
            {
                get { return text; }
                set { text = value; }
            }

         public double Lat
            {
                get { return lat; }
                set { lat = value; }
            }

         public double Longt
            {
                 get { return longt; }
                 set { longt = value; }
            }

    public String DateTimeStamp
    {
        get { return dateTimeStamp; }
        set { dateTimeStamp = value; }
    }
    public override string ToString()
    {
        return eventID + " " + text + " " + lat + " " + longt + " " + dateTimeStamp;
    }
}

class Facebook
{
    private String eventID;
    private String text;
    private double lat;
    private double longt;
    private String dateTimeStamp;

    public Facebook(String eventID, String text, double lat, double longt, String dateTimeStamp)
    {
        this.eventID = eventID;
        this.text = text;
        this.lat = lat;
        this.longt = longt;
        this.dateTimeStamp = dateTimeStamp;
    }

    public String EventID
    {
        get { return eventID; }
        set { eventID = value; }
    }

    public String Text
    {
        get { return text; }
        set { text = value; }
    }

    public double Lat
    {
        get { return lat; }
        set { lat = value; }
    }

    public double Longt
    {
        get { return longt; }
        set { longt = value; }
    }

    public String DateTimeStamp
    {
        get { return dateTimeStamp; }
        set { dateTimeStamp = value; }
    }
    public override string ToString()
    {
        return eventID + " " + text + " " + lat + " " + longt + " " + dateTimeStamp;
    }
}

class Photo
{
    private String eventID;
    private String filePath;
    private double lat;
    private double longt;

    public Photo(String eventID, String filePath, double lat, double longt)
    {
        this.eventID = eventID;
        this.filePath = filePath;
        this.lat = lat;
        this.longt = longt;
    }

    public String EventID
    {
        get { return eventID; }
        set { eventID = value; }
    }

    public String FilePath
    {
        get { return filePath; }
        set { filePath = value; }
    }

    public double Lat
    {
        get { return lat; }
        set { lat = value; }
    }

    public double Longt
    {
        get { return longt; }
        set { longt = value; }
    }

    public override string ToString()
    {
        return eventID + " " + filePath + " " + lat + " " + longt;
    }

}

class Video
{
    private String eventID;
    private String filePath;
    private double lat;
    private double longt;

    public Video(String eventID, String filePath, double lat, double longt)
    {
        this.eventID = eventID;
        this.filePath = filePath;
        this.lat = lat;
        this.longt = longt;
    }

    public String EventID
    {
        get { return eventID; }
        set { eventID = value; }
    }

    public String FilePath
    {
        get { return filePath; }
        set { filePath = value; }
    }

    public double Lat
    {
        get { return lat; }
        set { lat = value; }
    }

    public double Longt
    {
        get { return longt; }
        set { longt = value; }
    }

    public override string ToString()
    {
        return eventID + " " + filePath + " " + lat + " " + longt;
    }

}

class Tracklog
{
    private String eventID;
    private String filePath;
    private String data;
    private String[] dataPoints;
    private double lat;
    private double longt;
    private double lat2;
    private double longt2;


    public Tracklog(String eventID, String filePath, double lat, double longt, double lat2, double longt2)
    {
        this.eventID = eventID;
        this.filePath = filePath;
        this.lat = lat;
        this.longt = longt;
        this.lat2 = lat2;
        this.longt2 = longt2;
    }

    public String EventID
    {
        get { return eventID; }
        set { eventID = value; }
    }

    public String FilePath
    {
        get { return filePath; }
        set { filePath = value; }
    }

    public double Lat
    {
        get { return lat; }
        set { lat = value; }
    }

    public double Longt
    {
        get { return longt; }
        set { longt = value; }
    }

    public double Lat2
    {
        get { return lat2; }
        set { lat2 = value; }
    }

    public double Longt2
    {
        get { return longt; }
        set { longt = value; }
    }

    public override string ToString()
    {
        return eventID + " " + filePath + " " + lat + " " + longt + " " + lat2 + " " + longt2;
    }

}
}
