using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Assn1
{
    static class Program
    {
        /// <summary>
        /// loading xml events as markers
        /// </summary>
        [STAThread]
        static void Main()
        {
            ViewEvent viewEvent = new ViewEvent();
            viewEvent.ReadXML();

            AddEvent addEvent = new AddEvent();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Form1 Form1 = new Form1();
                

            //tweet event marker
            foreach (var pair in viewEvent.TweetDict)
            {

                
                double longt = viewEvent.TweetDict[pair.Key].Longt;
                double lat = viewEvent.TweetDict[pair.Key].Lat;
                String text = viewEvent.TweetDict[pair.Key].Text;
                String date = viewEvent.TweetDict[pair.Key].DateTimeStamp;

                Bitmap twitterMarker = (Bitmap)Image.FromFile("img/TwitterIcon.png");

                Form1.AddMarker(lat, longt, text, date, twitterMarker);
            }

            //facebook event marker
            foreach (var pair in viewEvent.FacebookDict)
            {
                
                double longt = viewEvent.FacebookDict[pair.Key].Longt;
                double lat = viewEvent.FacebookDict[pair.Key].Lat;
                String text = viewEvent.FacebookDict[pair.Key].Text;
                String date = viewEvent.FacebookDict[pair.Key].DateTimeStamp;

                Bitmap fbMarker = (Bitmap)Image.FromFile("img/FbIcon.png");

                Form1.AddMarker(lat, longt, text, date, fbMarker);
            }

            //photo event marker
            foreach (var pair in viewEvent.PhotoDict)
            {
                double longt = viewEvent.PhotoDict[pair.Key].Longt;
                double lat = viewEvent.PhotoDict[pair.Key].Lat;
                String text = viewEvent.PhotoDict[pair.Key].FilePath;
                String date = "";


                Bitmap photoMarker = (Bitmap)Image.FromFile("img/photoIcon.png");

                Form1.AddMarker(lat, longt, text, date, photoMarker);
            }

            //video event marker
            foreach (var pair in viewEvent.VideoDict)
            {
                double longt = viewEvent.VideoDict[pair.Key].Longt;
                double lat = viewEvent.VideoDict[pair.Key].Lat;
                String text = viewEvent.VideoDict[pair.Key].FilePath;
                String date = "";


                Bitmap videoMarker = (Bitmap)Image.FromFile("img/VidIcon.png");

                Form1.AddMarker(lat, longt, text, date, videoMarker);
            }
            //tracklog event marker (pushpin by default)
            foreach (var pair in viewEvent.TrackLogDict)
            {
                
                double longt = viewEvent.TrackLogDict[pair.Key].Longt;
                double lat = viewEvent.TrackLogDict[pair.Key].Lat;
                double longt2 = viewEvent.TrackLogDict[pair.Key].Longt2;
                double lat2 = viewEvent.TrackLogDict[pair.Key].Lat2;
                String text = viewEvent.TrackLogDict[pair.Key].FilePath;
  

                Form1.AddTrackLog(lat, longt, lat2, longt2, text);
            }

            Application.Run(Form1);
            
        }
    }
}
