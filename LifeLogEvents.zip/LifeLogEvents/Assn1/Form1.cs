﻿using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Assn1
{
    public partial class Form1 : Form
    {
        public bool ToRestart = false;
        public Form1()
        {
            InitializeComponent();
            InitializeMap();
        }

        private void btnload_Click(object sender, EventArgs e)
        {
            map.DragButton = MouseButtons.Left;
            map.MapProvider = GMapProviders.GoogleMap;
            double lat = Convert.ToDouble(txtlat.Text);
            double longt = Convert.ToDouble(txtlong.Text);
            map.Position = new GMap.NET.PointLatLng(lat, longt);
            map.MinZoom = 5; //minimum zoom level
            map.MaxZoom = 50; //max zoom level
            map.Zoom = 10; //current zoom level

        }

        //Called in main to setup the map at Perth, WA. Change Latdef and longdef for desired start location
        private void InitializeMap()
        {
            map.DragButton = MouseButtons.Left;
            map.MapProvider = GMapProviders.GoogleMap;
            double latdef = -31.953512;
            double longdef = 115.857048;
            map.ShowCenter = false;
            map.Position = new GMap.NET.PointLatLng(latdef, longdef);
            map.MinZoom = 5;
            map.MaxZoom = 50;
            map.Zoom = 10;

        }

        private void map_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var point = map.FromLocalToLatLng(e.X, e.Y);
                double lat = point.Lat;
                double lng = point.Lng;
                txtlat.Text = lat + "";
                txtlong.Text = lng + "";

                Form f = new Form2(lng, lat);
                f.Show();
              
            }
        }

        public void AddMarker(double lat, double longt, String text, String date, Bitmap img)
        {
            PointLatLng point = new PointLatLng(lat, longt);
            Console.WriteLine(lat + " \n" + longt);
            GMapMarker marker = new GMarkerGoogle(point, img);
            GMapOverlay markers = new GMapOverlay("Markers");
            if (!date.Equals(""))
            {
                marker.ToolTipText = $"Text: {text} \n Date: {date}";
            }
            else
            {
                marker.ToolTipText = $"file path: {text}";
            }

            var toolTip = new GMapToolTip(marker);
            marker.ToolTip.Fill = Brushes.Black;
            marker.ToolTip.Foreground = Brushes.White;
            marker.ToolTip.Stroke = Pens.Black;
            marker.ToolTip.TextPadding = new Size(30, 30);


            markers.Markers.Add(marker);
            map.Overlays.Add(markers);
        }

        public void AddTrackLog(double lat, double longt, Double lat2, double longt2, String text)
        {
            GMapOverlay polygons = new GMapOverlay("polygons");
            List<PointLatLng> points = new List<PointLatLng>();
            points.Add(new PointLatLng(lat, longt));
            points.Add(new PointLatLng(lat2, longt2));
            GMapPolygon polygon = new GMapPolygon(points, "tracklog");

            polygon.Stroke = new Pen(Color.Red, 1);

            PointLatLng point = new PointLatLng(lat, longt);
            PointLatLng point2 = new PointLatLng(lat2, longt2);
            GMapMarker marker = new GMarkerGoogle(point, GMarkerGoogleType.red_pushpin);
            GMapMarker marker2 = new GMarkerGoogle(point2, GMarkerGoogleType.red_pushpin);
            GMapOverlay markers = new GMapOverlay("Markers");
            marker.ToolTipText = $"Tracklog Name: {text}";

            var toolTip = new GMapToolTip(marker);
            marker.ToolTip.Fill = Brushes.Black;
            marker.ToolTip.Foreground = Brushes.White;
            marker.ToolTip.Stroke = Pens.Black;
            marker.ToolTip.TextPadding = new Size(30, 30);


            markers.Markers.Add(marker);
            markers.Markers.Add(marker2);
            map.Overlays.Add(markers);
            polygons.Polygons.Add(polygon);
            map.Overlays.Add(polygons);
        }

        private void refreshEvents_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(Application.ExecutablePath); //Application.Restart() was throwing an error
            Application.Exit();

        }
    }
}
