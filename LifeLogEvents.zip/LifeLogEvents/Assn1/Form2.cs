﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assn1
{
    public partial class Form2 : Form
    {
        public bool ToRestart = false;
        private double mouseX;
        private double mouseY;
        private String eventType = "twitter";

        public Form2()
        {
            InitializeComponent();
        }


        public Form2(double mouseX, double mouseY)
        {
            InitializeComponent();
            this.mouseX = mouseX;
            this.mouseY = mouseY;
        }

        public String EventType
        {
            get { return eventType; }
            set { eventType = value; }
        }

        public double MouseX
        {
            get { return mouseX; }
            set { mouseX = value; }
        }

        public double MouseY
        {
            get { return mouseY; }
            set { mouseY = value; }
        }

        private void photoRadButton_CheckedChanged(object sender, EventArgs e)
        {
            fbPanel.Visible = false;
            TwitterPanel.Visible = false;
            vidPanel.Visible = false;
            tracklogPanel.Visible = false;

            photoPanel.Visible = true;
            photoPanel.BringToFront();

            eventType = "photo";
        }

        private void tweetRadButton_CheckedChanged(object sender, EventArgs e)
        {
            fbPanel.Visible = false;
            photoPanel.Visible = false;
            vidPanel.Visible = false;
            tracklogPanel.Visible = false;

            TwitterPanel.Visible = true;
            TwitterPanel.BringToFront();

            eventType = "twitter";
        }

        private void vidRadButton_CheckedChanged(object sender, EventArgs e)
        {
            fbPanel.Visible = false;
            TwitterPanel.Visible = false;
            photoPanel.Visible = false;
            tracklogPanel.Visible = false;

            vidPanel.Visible = true;
            vidPanel.BringToFront();

            eventType = "video";
        }

        private void trackRadButton_CheckedChanged(object sender, EventArgs e)
        {
            fbPanel.Visible = false;
            TwitterPanel.Visible = false;
            vidPanel.Visible = false;
            photoPanel.Visible = false;

            tracklogPanel.Visible = true;
            tracklogPanel.BringToFront();

            eventType = "tracklog";
        }



        private void fbstatusRadButton_CheckedChanged(object sender, EventArgs e)
        {
            TwitterPanel.Visible = false;
            photoPanel.Visible = false;
            vidPanel.Visible = false;
            tracklogPanel.Visible = false;

            fbPanel.Visible = true;
            fbPanel.BringToFront();

            eventType = "facebook";

            String a = mouseX.ToString();
            String b = mouseY.ToString();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            AddEvent addEvent = new AddEvent();
            if (eventType == "twitter")
            {

                addEvent.AddTweet(tweetTxtBox.Text, dateTimeTwitter.Text, MouseX, MouseY);
                ToRestart = true;
                this.Close();
                
                
            }
            else if (eventType == "facebook")
            {
                addEvent.AddFacebook(fbstatusTxtBox.Text, dateTimeFacebook.Text, MouseX, MouseY);
                ToRestart = true;
                this.Close();
                
            }
            else if (eventType == "photo")
            {
                addEvent.AddPhoto(filePhotoTxtBox.Text, MouseX, MouseY);
                ToRestart = true;
                this.Close();
                
            }
            else if (eventType == "video")
            {
                addEvent.AddVideo(vidFileTextBox.Text, MouseX, MouseY);
                ToRestart = true;
                this.Close();
                
            }
            else if (eventType == "tracklog")
            {
                addEvent.AddTrackLog(fileTxtBox.Text, MouseX, MouseY, LatTxtBox.Text, longTxtBox.Text);
                ToRestart = true;
                this.Close();
               
            }
            else
            {
                this.Close();
            }
        }
    }
}
